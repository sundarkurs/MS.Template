﻿using MediatR;
using $ext_safeprojectname$.Application.Common.Wrappers;

namespace $safeprojectname$.Commands.Todo.Delete
{
    public class DeleteTodoCommand : IRequest<Response<bool>>
    {
        public int Id { get; set; }
    }
}
