﻿using MediatR;
using $ext_safeprojectname$.Application.Common.DTO;
using $ext_safeprojectname$.Application.Common.Wrappers;

namespace $safeprojectname$.Commands.Todo.Update
{
    public class UpdateTodoCommand : IRequest<Response<TodoDto>>
    {
        public int Id { get; set; }
        public TodoRequest Todo { get; set; }
    }
}
