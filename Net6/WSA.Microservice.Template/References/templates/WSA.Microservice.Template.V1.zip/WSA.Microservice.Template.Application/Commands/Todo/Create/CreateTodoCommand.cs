﻿using MediatR;
using $ext_safeprojectname$.Application.Common.DTO;
using $ext_safeprojectname$.Application.Common.Wrappers;

namespace $safeprojectname$.Commands.Todo.Create
{
    public class CreateTodoCommand : IRequest<Response<TodoDto>>
    {
        public TodoRequest Todo { get; set; }
    }
}
