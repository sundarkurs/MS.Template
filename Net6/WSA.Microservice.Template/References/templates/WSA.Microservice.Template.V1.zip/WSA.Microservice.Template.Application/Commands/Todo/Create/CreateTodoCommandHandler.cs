﻿using AutoMapper;
using MediatR;
using $ext_safeprojectname$.Application.Common.DTO;
using $ext_safeprojectname$.Application.Common.Interfaces.Repositories;
using $ext_safeprojectname$.Application.Common.Wrappers;

namespace $safeprojectname$.Commands.Todo.Create
{
    public class CreateTodoCommandHandler : IRequestHandler<CreateTodoCommand, Response<TodoDto>>
    {
        private readonly ITodoRepository _todoRepository;
        private readonly IMapper _mapper;

        public CreateTodoCommandHandler(ITodoRepository todoRepository, IMapper mapper)
        {
            _todoRepository = todoRepository;
            _mapper = mapper;
        }

        public async Task<Response<TodoDto>> Handle(CreateTodoCommand request, CancellationToken cancellationToken)
        {
            var todo = _mapper.Map<Domain.Entities.Todo>(request.Todo);

            var response = await _todoRepository.AddAsync(todo);

            var todoResponse = _mapper.Map<TodoDto>(response);

            return new Response<TodoDto>(todoResponse);
        }
    }
}
