﻿using AutoMapper;
using $ext_safeprojectname$.Application.Common.DTO;
using $ext_safeprojectname$.Domain.Entities;

namespace $safeprojectname$.Common.Mappings
{
    public class ApplicationProfile : Profile
    {
        public ApplicationProfile()
        {
            CreateMap<Todo, TodoDto>().ReverseMap();
            CreateMap<TodoRequest, Todo>();
        }
    }
}
