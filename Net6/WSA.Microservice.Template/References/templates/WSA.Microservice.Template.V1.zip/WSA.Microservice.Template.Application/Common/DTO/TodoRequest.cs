﻿namespace $safeprojectname$.Common.DTO
{
    public class TodoRequest
    {
        public string? Title { get; set; }
        public string? Description { get; set; }
    }
}
