﻿using $ext_safeprojectname$.Domain.Entities;

namespace $safeprojectname$.Common.Interfaces.Repositories
{
    public interface ITodoRepository : IBaseRepository<Todo>
    {
        Task<bool> IsTitleUniqueAsync(string code);
    }
}
