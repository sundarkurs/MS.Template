﻿using AutoMapper;
using MediatR;
using $ext_safeprojectname$.Application.Common.DTO;
using $ext_safeprojectname$.Application.Common.Interfaces.Repositories;
using $ext_safeprojectname$.Application.Common.Wrappers;

namespace $safeprojectname$.Queries.Todo
{
    public class GetAllTodos
    {
        public class Query : IRequest<PagedResponse<IEnumerable<TodoDto>>> { }

        public class Handler : IRequestHandler<Query, PagedResponse<IEnumerable<TodoDto>>>
        {
            private readonly ITodoRepository _todoRepository;
            private readonly IMapper _mapper;

            public Handler(ITodoRepository todoRepository, IMapper mapper)
            {
                _todoRepository = todoRepository;
                _mapper = mapper;
            }

            public async Task<PagedResponse<IEnumerable<TodoDto>>> Handle(Query request, CancellationToken cancellationToken)
            {
                var todos = await _todoRepository.GetAllAsync();
                var todosResponse = _mapper.Map<IEnumerable<TodoDto>>(todos);
                return new PagedResponse<IEnumerable<TodoDto>>(todosResponse, 1, 10);

            }
        }
    }
}
