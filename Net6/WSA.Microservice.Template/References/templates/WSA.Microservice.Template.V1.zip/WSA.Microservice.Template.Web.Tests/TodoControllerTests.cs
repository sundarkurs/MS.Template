using Xunit;

namespace $safeprojectname$
{
    public class TodoControllerTests
    {
        [Fact]
        public void Test1()
        {

        }
    }
}