﻿using Microsoft.AspNetCore.Mvc;
using $ext_safeprojectname$.Application.Commands.Todo.Create;
using $ext_safeprojectname$.Application.Commands.Todo.Delete;
using $ext_safeprojectname$.Application.Commands.Todo.Update;
using $ext_safeprojectname$.Application.Common.DTO;
using $ext_safeprojectname$.Application.Queries.Todo;
using $ext_safeprojectname$.Web.Attributes;

namespace $safeprojectname$.Controllers.Api
{
    //[TokenAuthorize]
    public class TodoController : BaseApiController
    {
        private readonly ILogger<TodoController> _logger;

        public TodoController(ILogger<TodoController> logger)
        {
            _logger = logger;
        }

        [HttpGet]
        public async Task<IActionResult> GetAllAsync()
        {
            return Ok(await Mediator.Send(new GetAllTodos.Query()));
        }

        [HttpGet("{id:int}")]
        public async Task<IActionResult> GetAsync(int id)
        {
            return Ok(await Mediator.Send(new GetTodo.Query { Id = id }));
        }

        [HttpPost]
        public async Task<IActionResult> CreateAsync(TodoRequest todo)
        {
            var response = await Mediator.Send(new CreateTodoCommand { Todo = todo });
            return Ok(response);
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateAsync(int id, TodoRequest todo)
        {
            var response = await Mediator.Send(new UpdateTodoCommand { Id = id, Todo = todo });
            return Ok(response);
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteAsync(int id)
        {
            var response = await Mediator.Send(new DeleteTodoCommand { Id = id });
            return Ok(response);
        }
    }
}
