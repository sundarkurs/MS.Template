﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace $safeprojectname$.Controllers
{
    [Authorize]
    public class BaseMvcController : Controller
    {
    }
}
