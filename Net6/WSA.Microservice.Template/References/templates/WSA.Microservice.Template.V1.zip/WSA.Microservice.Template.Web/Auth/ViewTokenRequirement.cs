﻿using Microsoft.AspNetCore.Authorization;

namespace $safeprojectname$.Auth
{
    public class ViewTokenRequirement : IAuthorizationRequirement
    {
        public ViewTokenRequirement(bool allowViewToken) =>
            AllowViewToken = allowViewToken;

        public bool AllowViewToken { get; }
    }
}
