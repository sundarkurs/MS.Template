﻿using MediatR;
using Microsoft.Extensions.Logging;
using $ext_safeprojectname$.Application.Queries.Todo;
using $ext_safeprojectname$.WebJob.InboundProcess.Interfaces;

namespace $safeprojectname$.Services
{
    public class TodoImporter : ITodoImporter
    {
        private readonly ILogger<TodoImporter> _logger;
        private IMediator _mediator;

        public TodoImporter(ILogger<TodoImporter> logger, IMediator mediator)
        {
            _logger = logger;
            _mediator = mediator;
        }

        public async Task ProcessAsync()
        {
            _logger.LogInformation("Process started");

            var response = await _mediator.Send(new GetAllTodos.Query());

            return;
        }
    }
}
