﻿
namespace $safeprojectname$.Interfaces
{
    public interface ITodoImporter
    {
        Task ProcessAsync();
    }
}
