﻿using Microsoft.EntityFrameworkCore;
using $ext_safeprojectname$.Application.Common.Interfaces.Repositories;
using $ext_safeprojectname$.Domain.Entities;
using $ext_safeprojectname$.Infrastructure.Persistence.Contexts;

namespace $safeprojectname$.Repositories
{
    public class TodoRepository : BaseRepository<Todo>, ITodoRepository
    {
        private readonly DbSet<Todo> _todos;

        public TodoRepository(TemplateContext dbContext) : base(dbContext)
        {
            _todos = dbContext.Set<Todo>();
        }

        public Task<bool> IsTitleUniqueAsync(string title)
        {
            return _todos.AllAsync(p => p.Title != title);
        }
    }
}
