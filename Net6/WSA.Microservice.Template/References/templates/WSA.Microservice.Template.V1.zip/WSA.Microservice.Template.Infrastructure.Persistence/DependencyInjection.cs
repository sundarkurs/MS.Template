﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using $ext_safeprojectname$.Application.Common.Interfaces.Repositories;
using $ext_safeprojectname$.Infrastructure.Persistence.Contexts;
using $ext_safeprojectname$.Infrastructure.Persistence.Repositories;

namespace $safeprojectname$
{
    public static class DependencyInjection
    {
        public static void AddPersistenceServices(this IServiceCollection services, IConfiguration configuration)
        {  
            // Database context
            services.AddDbContext<TemplateContext>(options =>
               options.UseSqlServer(
                   configuration.GetConnectionString("DefaultConnection"),
                   b => b.MigrationsAssembly(typeof(TemplateContext).Assembly.FullName)));

            // Repositories
            services.AddTransient(typeof(IBaseRepository<>), typeof(BaseRepository<>));
            services.AddTransient<ITodoRepository, TodoRepository>();
        }
    }
}
